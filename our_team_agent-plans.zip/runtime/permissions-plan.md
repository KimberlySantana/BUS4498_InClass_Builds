# Permissions and boundaries plan

Written in plain words with the BUS 4498 Agent Builder Kit. Our AI assistant builds it following `runtime/permission-rules.md`. Where this plan and our task specifications disagree, this plan wins.

- Agent: The goal of our AI IT Help Desk Agent is to help employees quickly solve common technology problems by identifying the issue, providing troubleshooting steps, and sending more urgent issues to IT staff. (`our_team_agent`)
- Owner, who answers for this agent: Kimberly Santana and Karen Conde
- Written on: November 9, 2026

## 1. May (on its own)

| # | Action |
|---|---|
| 1 | receive and log technology problem requests with a unique request ID |
| 2 | Gather available problem infromation and identify missing non confidential details |
| 3 | Classify a problem using approved categories, urgency rules, and supported status rrules |
| 4 | send an IT handoff package and create or update a service desk ticket using the request ID |
| 5 | read the approved IT knowledge base and relevant trusted lessons before similar work |

## 2. May, with a limit

| # | What | The limit | Kind | Who can change it |
|---|---|---|---|---|
| 1 | Ask an employee for missing non-confidential information. | Maximum two focused requests per request ID | A number a reviewer can change in the app | A signed-in reviewer, in the app, with a reason |
| 2 | Send approved troubleshooting guidance | One primary step set and up to to approved alternate step sets per request ID | A number a reviewer can change in the app | A signed-in reviewer, in the app, with a reason |
| 3 | Send a resolution reminder | One reminder after no employee response | A number a reviewer can change in the app | A signed-in reviewer, in the app, with a reason |
| 4 | Operate on new support requests | The agent may act only while the Agent Enables switch is on | A number a reviewer can change in the app | A signed-in reviewer, in the app, with a reason |

## 3. Ask first (hold for a person)

| # | When | What the agent does instead |
|---|---|---|
| 1 | The problem is unsupported, unclear, or has no matching approved knowledge-base guidance. | The employee asks the agent to change access permissions, reset security settings, bypass security controls, or perform an action outside approved troubleshooting steps. |
| 2 | Two missing-information requests do not provide enough usable information. | The approved primary and alternate troubleshooting steps do not resolve the issue. |

## 4. Never

| # | Never | Where it is enforced |
|---|---|---|
| 1 | Ask for, store, or share passwords, MFA codes, security answers, or unnecessary personal information. | Code and a database rule |
| 2 | Tell an employee to disable security settings, bypass security controls, or change access permissions. | Code |
| 3 | Use troubleshooting steps that are not in the IT-approved knowledge base. | Code and a database rule |
| 4 | Send case information to anyone outside the employee linked to the request or the approved IT service-desk queue. | Code and a database rule |
| 5 | Create a lesson from an employee message or unverified outcome. | Code and a database rule |

## 5. Who signs off

| Decision | Who | How |
|---|---|---|
| Urgent, security, unsupported, or unresolved cases | On-duty IT Support Team member | The IT staff member selects the ticket action and records the decision in the service-desk ticket. |
| Changes to the approved knowledge base or escalation rules | IT Support Team lead | The lead approves or rejects the change in the knowledge-base review screen. |
| A change to agent limits or Agent Enabled status | IT Support Team lead | The lead changes the setting in the app and records a reason. |

## The off switch

The IT Support Team lead can pause the agent by turning off the Agent Enabled switch in the service-desk settings. The system checks this switch before every task and tool call. When paused, the agent does nothing and creates no messages, tickets, updates, or lessons.

## How mistakes are reported

Employees and IT staff can use a Report Agent Mistake button on a service desk ticket. The report records the request ID, the task involved, and the reported issue. Reports go to the IT Support Team lead for review within one business day. Reviews are blame free and focus on correcting the ticket, knowledge base, workflow rule, or agent limit.

## Rules we keep

- Every permission starts off. The agent may do only what this plan lists under *May* and *May, with a limit*.
- Writing a permission down does not enforce it. Every limit and every *Never* is enforced in code or in a database rule, never in instructions alone.
- A limit a person may change is a setting with an owner and a reason, which the code reads on every run.
- Asking means holding, not guessing: the record waits with a plain reason that names what is missing.
- A sign-off is a click in the app, recorded with who and when. A chat message is not a sign-off.
- Test mode never acts: with `dry_run`, the agent decides but saves nothing.
