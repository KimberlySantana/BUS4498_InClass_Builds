# Memory plan

Written in plain words with the BUS 4498 Agent Builder Kit. Our AI assistant designs the files and tables from it, following `runtime/memory-rules.md`. This plan adds to `runtime/hosting-plan.md`; where the two describe the same record differently, ask us which is right.

## What our agent must know or remember

| # | What | Kind | Where it lives | Who can change it | When it expires |
|---|---|---|---|---|---|
| 1 | Approved problem categories, troubleshooting steps, urgency rules, security boundaries, and escalation rules | Knowledge it reads | A file only we change | Only the builders | Never |
| 2 | Request ID, task status, classification, urgency, steps already snet, escalation reason, ticket ID, and final status. It must not include passwords, MFA codes, security answers, or unnecessary personal information. | What happened | A file only we change | The agent itself | After a date or deadline |
| 3 | Lessons created only from a trusted final outcome recorded by IT staff, including the outcome, reason, related problem type, and replacement date if a newer lesson conflicts. | Lessons it learns | A file only we change | Only the builders | When a newer record replaces it |

## Lessons it learns

- **It learns from:** A trusted final outcome from T9 IT staff review and respond. It must never create a lesson just from an employee’s request, message, or unverified feedback.
- **A lesson might say:** If IT staff marks a problem type as unsupported by the approved knowledge base, the agent should send similar future cases directly to T7 Gather necessary information instead of offering troubleshooting steps.
- It learns only from trusted outcomes, never from text in an input. A lesson can add caution, never loosen a rule or approve anything. Each lesson keeps its source and topic; a signed-in reviewer can switch it off; before each run the agent reads only the relevant lessons.

## What must never happen twice

Never ask an employee for a password, MFA code, security answer, or unnecessary personal information. 

Never repeat troubleshooting steps already recorded as unsuccessful for the same request. 

Never create duplicate IT tickets for the same request ID. 

Never treat employee feedback as a trusted lesson without an IT staff outcome.
