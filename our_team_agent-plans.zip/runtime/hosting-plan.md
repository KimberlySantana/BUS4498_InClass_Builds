# Hosting plan

Written in plain words with the BUS 4498 Agent Builder Kit. Our AI assistant turns it into a GitHub Pages website and a Supabase backend, following `runtime/hosting-rules.md`. Where this plan and our task specifications disagree, this plan wins.

## Our project

- GitHub repository: https://github.com/KimberlySantana/BUS4498_Team_Build
- Our agent’s folder: `our_team_agent` (our plans are in `our_team_agent/runtime/`)
- Supabase project: https://kxnohgakjszbhiubsiol.supabase.co
- Owner of the repository and the Supabase project: Kimberly Santana
- Teammate: Karen Conde, a collaborator on GitHub and a Developer in the Supabase organization
- We say “I’m working on it” and “pushed” in: I'm working on it. One of us works at a time.

## What our agent does

The goal of our AI IT Help Desk Agent is to help employees quickly solve common technology problems by identifying the issue, providing troubleshooting steps, and sending more urgent issues to IT staff.

## Our tasks

Use the tasks in our task specifications: `our_team_agent/agent/workflow-of-tasks.md` and `our_team_agent/agent/task-specs/`.

## Who can see or change what

Both employees and IT staff

## External tools and applications

None: our agent uses no external tools or applications.

## Files people upload

None.
